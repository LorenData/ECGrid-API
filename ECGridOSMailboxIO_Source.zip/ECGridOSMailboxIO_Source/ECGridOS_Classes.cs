﻿using System.Text.Json.Serialization;

namespace ECGridOSMailboxIO;

#region Object Classes

/// <summary>
/// ECGrid ID Info Object
/// </summary>
public class ECGridIDInfo
{
    public int ECGridID { get; set; }
    public int NetworkID { get; set; }
    public string? NetworkName { get; set; }
    public int MailboxID { get; set; }
    public string? MailboxName { get; set; }
    public string? Qualifier { get; set; }
    public string? ID { get; set; }
    public string? Description { get; set; }
    public string? DataEMail { get; set; }
    public bool MailboxDefault { get; set; }
    public StatusECGridID Status { get; set; }
    public UseType UseType { get; set; }
    public UserIDInfo? Owner { get; set; }
    public ECGridOwnerInfo? OwnerInfo { get; set; }
    public MailboxConfig? Config { get; set; }
}

/// <summary>
/// ECGrid Owner Info Object
/// </summary>
public class ECGridOwnerInfo
{
    public int NetworkID { get; set; }
    public string? NetworkName { get; set; }
    public int MailboxID { get; set; }
    public string? MailboxName { get; set; }
    public System.DateTime Created { get; set; }
    public System.DateTime Modified { get; set; }
    public System.DateTime Effective { get; set; }
    public System.DateTime Expires { get; set; }
    public System.DateTime LastTraffic { get; set; }
    public RoutingGroup RoutingGroup { get; set; }
}

/// <summary>
/// File Info Object
/// </summary>
public class FileInfo
{
    public long ParcelID { get; set; }
    public string? FileName { get; set; }
    public DateTime FileDate { get; set; }
    public int Bytes { get; set; }
    public EDIStandard Standard { get; set; }
    public byte[]? Content { get; set; }
    public string? ContentBase64String { get; set; }
    public bool routerArchive { get; set; }
}

/// <summary>
/// Interchange ID Info Object
/// </summary>
public class InterchangeIDInfo
{
    public long InterchangeID { get; set; }
    public DateTime InterchangeProcessDate { get; set; }
    public int NetworkIDFrom { get; set; }
    public string? NetworkNameFrom { get; set; }
    public int MailboxIDFrom { get; set; }
    public int NetworkIDTo { get; set; }
    public string? NetworkNameTo { get; set; }
    public int MailboxIDTo { get; set; }
    public EDIStandard Standard { get; set; }
    public int Bytes { get; set; }
    public string? InterchangeControlID { get; set; }
    public DateTime InterchangeDateTime { get; set; }
    public DateTime StatusDate { get; set; }
    public string? StatusCode { get; set; }
    public string? StatusMessage { get; set; }
    public string? DocumentType { get; set; }
    public DateTime ArchiveDate { get; set; }
    public string? Header { get; set; }
    public ECGridIDInfo? TPFrom { get; set; }
    public ECGridIDInfo? TPTo { get; set; }
    public ParcelIDInfo[]? Parcels { get; set; }
}

/// <summary>
/// Mailbox Config Object
/// </summary>
public class MailboxConfig
{
    public short InBoxTimeout { get; set; }
    public byte SegTerm { get; set; }
    public byte ElmSep { get; set; }
    public byte SubElmSep { get; set; }
    public string? EBCDICFilter { get; set; }
    public bool FTPasciiFilter { get; set; }
    public bool LowPassFilter { get; set; }
    public bool MailbagPassThrough { get; set; }
    public bool DeleteOnDownload { get; set; }
    public bool StripDirectedEnvelope { get; set; }
}

/// <summary>
/// Manifest Info Object
/// </summary>
public class ManifestInfo
{
    public DateTime ManifestDate { get; set; }
    public int NetworkID { get; set; }
    public string? NetworkName { get; set; }
    public ManifestType Type { get; set; }
    public long ParcelID { get; set; }
    public long InterchangeID { get; set; }
    public string? StatusCode { get; set; }
    public string? StatusMessage { get; set; }
    public string? StatusColor { get; set; }
}

/// <summary>
/// Parcel ID Info Object
/// </summary>
public class ParcelIDInfo
{
    public long ParcelID { get; set; }
    public int ParcelBytes { get; set; }
    public DateTime ParcelDate { get; set; }
    public int ActualBytes { get; set; }
    public int NetworkIDFrom { get; set; }
    public string? NetworkNameFrom { get; set; }
    public int MailboxIDFrom { get; set; }
    public string? MailboxNameFrom { get; set; }
    public int NetworkIDTo { get; set; }
    public string? NetworkNameTo { get; set; }
    public int MailboxIDTo { get; set; }
    public string? MailboxNameTo { get; set; }
    public string? FileName { get; set; }
    public string? MailbagControlID { get; set; }
    public DateTime ArchiveDate { get; set; }
    public DateTime StatusDate { get; set; }
    public string? StatusCode { get; set; }
    public string? StatusMessage { get; set; }
    public short LocalStatus { get; set; }
    public DateTime LocalStatusDate { get; set; }
    public ParcelValid Valid { get; set; }
    public string? Acknowledgment { get; set; }
    public Direction Direction { get; set; }
    public InterchangeIDInfo[]? Interchanges { get; set; }
    public ManifestInfo[]? Log { get; set; }
}

/// <summary>
/// Parcel ID Info Collection Object
/// </summary>
public class ParcelIDInfoCollection
{
    public short PageSize { get; set; }
    public short PageNumber { get; set; }
    public short Count { get; set; }
    public int TotalRecords { get; set; }
    public short TotalPages { get; set; }
    public ParcelIDInfo[]? ParcelIDInfoList { get; set; }
}

/// <summary>
/// Session Info Object
/// </summary>
public class SessionInfo
{
    public string? ECGridOSVersion { get; set; }
    public string? SessionID { get; set; }
    public int SessionEventID { get; set; }
    public int UserID { get; set; }
    public string? LoginName { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? Company { get; set; }
    public string? EMail { get; set; }
    public string? Phone { get; set; }
    public float TimeZoneOffset { get; set; }
    public AuthLevel AuthLevel { get; set; }
    public DateTime LastLogin { get; set; }
    public short OpenSessions { get; set; }
    public short TimeOut { get; set; }
    public int NetworkID { get; set; }
    public int MailboxID { get; set; }
    [JsonPropertyName("ip")]
    public string? IP { get; set; }
}

/// <summary>
/// User ID Info Object
/// </summary>
public class UserIDInfo
{
    public int UserID { get; set; }
    public string? LoginName { get; set; }
    public string? RecoveryQuestion { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? Company { get; set; }
    public string? EMail { get; set; }
    public string? Phone { get; set; }
    public string? CellPhone { get; set; }
    public CellCarrier CellCarrier { get; set; }
    public short TimeZoneOffset { get; set; }
    public int NetworkID { get; set; }
    public int MailboxID { get; set; }
    public AuthLevel AuthLevel { get; set; }
    public DateTime Created { get; set; }
    public DateTime Modified { get; set; }
    public DateTime LastLogin { get; set; }
    public Status Status { get; set; }
    public bool LockedOut { get; set; }
    public short OpenSessions { get; set; }
}

#endregion

#region Enums

/// <summary>
/// Auth Level ENUM
/// </summary>
public enum AuthLevel
{
    NoChange,
    Root,
    TechOps,
    NetOps,
    NetworkAdmin,
    NetworkUser,
    MailboxAdmin,
    MailboxUser,
    TPUser,
    General,
}

/// <summary>
/// Cell Carrier ENUM
/// </summary>
public enum CellCarrier
{
    NoChange,
    Undefined,
    ATTCingular,
    Verizon,
    TMobile,
    SprintPCS,
    Nextel,
    Alltel,
    VirginMobile,
    ATTPreCingular,
    ATT,
    BoostMobile,
    USCellular,
    MetroPCS,
    Powertel,
}

/// <summary>
/// Direction ENUM
/// </summary>
public enum Direction
{
    NoDir,
    OutBox,
    InBox,
}

/// <summary>
/// EDI Standard ENUM
/// </summary>
public enum EDIStandard
{
    X12,
    EDIFACT,
    TRADACOMS,
    VDA,
    XML,
    TXT,
    PDF,
    Binary,
}

/// <summary>
/// Manifest Type ENUM
/// </summary>
public enum ManifestType
{
    System,
    Error,
    Manual,
    ECGridOS,
}

/// <summary>
/// Parcel Valid ENUM
/// </summary>
public enum ParcelValid
{
    Pending,
    Invalid,
    Valid,
    PartialValid,
    ValidNoneRouted,
    Duplicate,
    ZeroByte,
    VallidRouted,
    ValidPartialRouted,
    ValidNoneRoutedx,
}

/// <summary>
/// Routing Group ENUM
/// </summary>
public enum RoutingGroup
{
    ProductionA,
    ProductionB,
    Migration1,
    Migration2,
    NetOpsOnly1,
    NetOpsOnly2,
    ManagedFileTransfer,
    SuperHub,
    Test,
    Suspense1,
    Suspense2,
    Suspense3,
}

/// <summary>
/// Status ENUM
/// </summary>
public enum Status
{
    Development,
    Active,
    Preproduction,
    Suspended,
    Terminated,
}

/// <summary>
/// Status EDGridID ENUM
/// </summary>
public enum StatusECGridID
{
    Active,
    AutoRoute,
    Pending,
    Suspended,
    Terminated,
    Duplicate,
}

/// <summary>
/// Use Type ENUM
/// </summary>
public enum UseType
{
    Undefined,
    Test,
    Production,
    TestAndProduction,
}

#endregion

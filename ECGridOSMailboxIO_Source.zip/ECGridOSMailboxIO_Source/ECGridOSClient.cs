﻿using System.Globalization;
using System.Xml.Serialization;

namespace ECGridOSMailboxIO;

/// <summary>
/// Interface for ECGridOSClient Service
/// </summary>
public interface IECGridOSClient
{
    #region Parcel/File

    Task<ECGridOSMailboxIO.FileInfo?> ParcelDownload(string apikey, long parcelID);
    Task<bool?> ParcelDownloadConfirm(string apikey, long parcelID);
    Task<bool?> ParcelDownloadReset(string apikey, long parcelID);
    Task<ParcelIDInfoCollection?> ParcelInBox(string apikey);
    Task<int?> ParcelUploadA(string sessionID, string fileName, string contentBase64);
    Task<int?> ParcelUploadMftA(string apikey, string fileName, string contentBase64, int eCGridIDFrom, int eCGridIDTo);

    #endregion

    #region Version

    Task<string?> Version();

    #endregion

    #region WhoAmI

    Task<SessionInfo?> WhoAmI(string apikey);

    #endregion
}

/// <summary>
/// ECGridOS Client Service
/// </summary>
public class ECGridOSClient : IECGridOSClient
{
    #region Class Variables

    private readonly HttpClient _client;
    private readonly string domain_name = "https://os.ecgrid.io/";

    #endregion

    #region Constructor

    /// <summary>
    /// Constructor for the ECGridOS Client
    /// </summary>
    /// <param name="client">httpclient to use for connecting to ECGridOS</param>
    public ECGridOSClient(HttpClient client)
    {
        _client = client;
    }

    #endregion

    #region Parcel/File

    /// <summary>
    /// Parcel Download API Call
    /// </summary>
    /// <param name="apikey"></param>
    /// <param name="parcelID"></param>
    /// <returns></returns>
    /// <exception cref="ECGridOSAPIException"></exception>
    public async Task<ECGridOSMailboxIO.FileInfo?> ParcelDownload(string apikey, long parcelID)
    {
        // Post Form Parameters
        Dictionary<string, string> parameters = new Dictionary<string, string> {
            { "SessionID", apikey },
            { "ParcelID", parcelID.ToString(CultureInfo.InvariantCulture) }
        };

        HttpRequestMessage requestMessage = new HttpRequestMessage
        {
            Method = HttpMethod.Post,
            RequestUri = new Uri($"{_client.BaseAddress}ParcelDownload"),
            Content = new FormUrlEncodedContent(parameters)
        };

        using HttpResponseMessage responseHeader = await _client.SendAsync(requestMessage, HttpCompletionOption.ResponseHeadersRead);
        if (responseHeader.IsSuccessStatusCode)
        {
            return (ECGridOSMailboxIO.FileInfo?)new XmlSerializer(typeof(ECGridOSMailboxIO.FileInfo), domain_name).Deserialize(await responseHeader.Content.ReadAsStreamAsync());
        }
        else
        {
            throw new ECGridOSAPIException(await responseHeader.Content.ReadAsStringAsync());
        }
    }

    /// <summary>
    /// PArcel Download Confirm API Call
    /// </summary>
    /// <param name="apikey"></param>
    /// <param name="parcelID"></param>
    /// <returns></returns>
    /// <exception cref="ECGridOSAPIException"></exception>
    public async Task<bool?> ParcelDownloadConfirm(string apikey, long parcelID)
    {
        // Post Form Parameters
        Dictionary<string, string> parameters = new Dictionary<string, string> {
            { "SessionID", apikey },
            { "ParcelID", parcelID.ToString() }
        };

        HttpRequestMessage requestMessage = new HttpRequestMessage
        {
            Method = HttpMethod.Post,
            RequestUri = new Uri($"{_client.BaseAddress}ParcelDownloadConfirm"),
            Content = new FormUrlEncodedContent(parameters)
        };

        using HttpResponseMessage responseHeader = await _client.SendAsync(requestMessage, HttpCompletionOption.ResponseHeadersRead);
        if (responseHeader.IsSuccessStatusCode)
        {
            return (bool?)new XmlSerializer(typeof(bool), domain_name).Deserialize(await responseHeader.Content.ReadAsStreamAsync());
        }
        else
        {
            throw new ECGridOSAPIException(await responseHeader.Content.ReadAsStringAsync());
        }
    }

    /// <summary>
    /// Parcel Download Reset API Call
    /// </summary>
    /// <param name="apikey"></param>
    /// <param name="parcelID"></param>
    /// <returns></returns>
    /// <exception cref="ECGridOSAPIException"></exception>
    public async Task<bool?> ParcelDownloadReset(string apikey, long parcelID)
    {
        // Post Form Parameters
        Dictionary<string, string> parameters = new Dictionary<string, string> {
            { "SessionID", apikey },
            { "ParcelID", parcelID.ToString() }
        };

        HttpRequestMessage requestMessage = new HttpRequestMessage
        {
            Method = HttpMethod.Post,
            RequestUri = new Uri($"{_client.BaseAddress}ParcelDownloadReset"),
            Content = new FormUrlEncodedContent(parameters)
        };

        using HttpResponseMessage responseHeader = await _client.SendAsync(requestMessage, HttpCompletionOption.ResponseHeadersRead);
        if (responseHeader.IsSuccessStatusCode)
        {
            return (bool?)new XmlSerializer(typeof(bool), domain_name).Deserialize(await responseHeader.Content.ReadAsStreamAsync());
        }
        else
        {
            throw new ECGridOSAPIException(await responseHeader.Content.ReadAsStringAsync());
        }
    }

    /// <summary>
    /// Parcel Inbox API Call
    /// </summary>
    /// <param name="apikey"></param>
    /// <returns></returns>
    /// <exception cref="ECGridOSAPIException"></exception>
    public async Task<ParcelIDInfoCollection?> ParcelInBox(string apikey)
    {
        // Post Form Parameters
        Dictionary<string, string> parameters = new Dictionary<string, string> {
            { "SessionID", apikey }
        };

        HttpRequestMessage requestMessage = new HttpRequestMessage
        {
            Method = HttpMethod.Post,
            RequestUri = new Uri($"{_client.BaseAddress}ParcelInBox"),
            Content = new FormUrlEncodedContent(parameters)
        };

        using HttpResponseMessage responseHeader = await _client.SendAsync(requestMessage, HttpCompletionOption.ResponseHeadersRead);
        if (responseHeader.IsSuccessStatusCode)
        {
            return (ParcelIDInfoCollection?)new XmlSerializer(typeof(ParcelIDInfoCollection), domain_name).Deserialize(await responseHeader.Content.ReadAsStreamAsync());
        }
        else
        {
            throw new ECGridOSAPIException(await responseHeader.Content.ReadAsStringAsync());
        }
    }

    public async Task<int?> ParcelUploadA(string sessionID, string fileName, string contentBase64)
    {
        // Post Form Parameters
        Dictionary<string, string> parameters = new Dictionary<string, string> {
            { "SessionID", sessionID },
            { "FileName", fileName },
            { "ContentBase64", contentBase64 }
        };

        HttpRequestMessage requestMessage = new HttpRequestMessage
        {
            Method = HttpMethod.Post,
            RequestUri = new Uri($"{_client.BaseAddress}ParcelUploadA"),
            Content = new FormUrlEncodedContent(parameters)
        };

        using HttpResponseMessage responseHeader = await _client.SendAsync(requestMessage, HttpCompletionOption.ResponseHeadersRead);
        if (responseHeader.IsSuccessStatusCode)
        {
            return (int?)new XmlSerializer(typeof(int), domain_name).Deserialize(await responseHeader.Content.ReadAsStreamAsync());
        }
        else
        {
            throw new ECGridOSAPIException(await responseHeader.Content.ReadAsStringAsync());
        }
    }

    /// <summary>
    /// ECGridOS Parcel Upload Mft API Call
    /// Managed File Transfer File Upload Process to specified ECGridIDs 
    /// </summary>
    /// <param name="apikey"></param>
    /// <param name="fileName"></param>
    /// <param name="bytes"></param>
    /// <param name="content"></param>
    /// <param name="eCGridIDFrom"></param>
    /// <param name="eCGridIDTo"></param>
    /// <returns></returns>
    public async Task<int?> ParcelUploadMftA(string apikey, string fileName, string contentBase64, int eCGridIDFrom, int eCGridIDTo)
    {
        // Post Form Parameters
        Dictionary<string, string> parameters = new Dictionary<string, string> {
            { "SessionID", apikey },
            { "FileName", fileName },
            { "ContentBase64", contentBase64 },
            { "ECGridIDFrom", eCGridIDFrom.ToString() },
            { "ECGridIDTo", eCGridIDTo.ToString() }
        };

        HttpRequestMessage requestMessage = new HttpRequestMessage
        {
            Method = HttpMethod.Post,
            RequestUri = new Uri($"{_client.BaseAddress}ParcelUploadMftA"),
            Content = new FormUrlEncodedContent(parameters)
        };

        using HttpResponseMessage responseHeader = await _client.SendAsync(requestMessage, HttpCompletionOption.ResponseHeadersRead);
        if (responseHeader.IsSuccessStatusCode)
        {
            return (int?)new XmlSerializer(typeof(int), domain_name).Deserialize(await responseHeader.Content.ReadAsStreamAsync());
        }
        else
        {
            throw new ECGridOSAPIException(await responseHeader.Content.ReadAsStringAsync());
        }
    }

    #endregion

    #region Version

    /// <summary>
    /// ECGridOS Version API Call
    /// </summary>
    /// <returns>string - ECGridOS Version Info</returns>
    public async Task<string?> Version()
    {
        HttpRequestMessage requestMessage = new HttpRequestMessage
        {
            Method = HttpMethod.Post,
            RequestUri = new Uri($"{_client.BaseAddress}Version")
        };

        using HttpResponseMessage responseHeader = await _client.SendAsync(requestMessage, HttpCompletionOption.ResponseHeadersRead);
        if (responseHeader.IsSuccessStatusCode)
        {
            return (string?)new XmlSerializer(typeof(string), domain_name).Deserialize(await responseHeader.Content.ReadAsStreamAsync());
        }
        else
        {
            throw new ECGridOSAPIException(await responseHeader.Content.ReadAsStringAsync());
        }
    }

    #endregion

    #region WhoAmI

    /// <summary>
    /// ECGridOS WhoAmI API Call
    /// </summary>
    /// <param name="apikey"></param>
    /// <returns>SessionInfo</returns>
    public async Task<SessionInfo?> WhoAmI(string apikey)
    {
        // Post Form Parameters
        Dictionary<string, string> parameters = new Dictionary<string, string> {
            { "SessionID", $"{apikey}" }
        };

        HttpRequestMessage requestMessage = new HttpRequestMessage
        {
            Method = HttpMethod.Post,
            RequestUri = new Uri($"{_client.BaseAddress}WhoAmI"),
            Content = new FormUrlEncodedContent(parameters)
        };

        using HttpResponseMessage responseHeader = await _client.SendAsync(requestMessage, HttpCompletionOption.ResponseHeadersRead);
        if (responseHeader.IsSuccessStatusCode)
        {
            return (SessionInfo?)new XmlSerializer(typeof(SessionInfo), domain_name).Deserialize(await responseHeader.Content.ReadAsStreamAsync());
        }
        else
        {
            throw new ECGridOSAPIException(await responseHeader.Content.ReadAsStringAsync());
        }
    }

    #endregion
}

public class ECGridOSAPIException : Exception
{
    public ECGridOSAPIException(string message) : base(message) { }
}
![ECGrid Logo](https://www.ld.com/wp-content/uploads/2015/08/ecgridlogo1.png)

# ECGridOS Mailbox IO Console App

## Program Summary

A console program for upload and downloading file using the ECGridOS API.

Upload a single EDI file by specifying the path combined with the filename.
Upload a single MFT or Non-EDI file by specifying the path combined with the filename and both ECGrid IDs.
Upload a multiple EDI files by specifying the path or directory on the file system.
Upload a multiple MFT or Non-EDI files by specifying the path or directory on the file system and both ECGrid IDs.
Download all Pending files from the ECGrid InBox to a specified folder or directory.

## Getting Started

All commands and options can be viewed by running the program with the -help option or with no options.
	ECGridOSMailboxIO -help

To upload files from a directoy with logging use this basic command.
    ECGridOSMailboxIO <apikey> <directory example = c:\ecgridos\outbox> -upload -log

To download files to a directoy with logging use this basic command.
    ECGridOSMailboxIO <apikey> <directory example = c:\ecgridos\inbox> -download -log

Common issues...

Argument count is not being identified correctly.
  
  Try removing the trailing slach for a directory location.
	C:\\ECGridOS\Inbox instead of C:\\ECGridOS\Inbox\
  Use \"...\" on the to allow spaces in the LocalDirectory
    "C:\\ECGridOS\In box" instead of C:\\ECGridOS\In box

Program Can't access files or directories
  Try running the program as an administrator or allowing the program permissions to the specified directory/file.

### Standard Usage Arguments

ECGridOSMailboxIO <APIKey> <LocalDirectory|LocalFile> <-upload|-download> [-log]

   APIKey                            - must be previously registered on ECGridOS
   LocalDirectory                    - the local directory - if upload, all files in the directory will be sent.
                                       Use \"...\" on the command line to allow spaces in the LocalDirectory
   LocalFile                         - a local file for upload only
                                       Use \"...\" on the command line to allow spaces in the LocalFile
   -upload[:ECGridIDFrom,ECGridIDTo] - direction of file transfer
   -download                         - direction of file transfer
   -log                              - if a text file log should be written to in addition to the console.

### Services and APIs

 - ECGridOSClient
	- [Version](https://os.ecgrid.io/v4.1/prod/ECGridOS.asmx?op=Version)
		- Returns the current version of the ECGridOS API Service, also used to check if service is available.
	- [WhoAmI](https://os.ecgrid.io/v4.1/prod/ECGridOS.asmx?op=WhoAmI)
		- Returns the current session information for the provided APIKey identifying the user.
	- [ParcelUploadMftA](https://os.ecgrid.io/v4.1/prod/ECGridOS.asmx?op=ParcelUploadMftA) 
		- Managed File Transfer (MFT, non-EDI data) upload to the APIKey user OutBox.
	- [ParcelUploadA](https://os.ecgrid.io/v4.1/prod/ECGridOS.asmx?op=ParcelUploadA) 
		- Upload an X12, EDIFACT, Tradacoms or VDA Parcel to the APIKey user OutBox.
	- [ParcelInBox](https://os.ecgrid.io/v4.1/prod/ECGridOS.asmx?op=ParcelInBox) 
		- Current Pending Files for the APIKey user InBox.
	- [ParcelDownload](https://os.ecgrid.io/v4.1/prod/ECGridOS.asmx?op=ParcelDownload) 
		- Download Parcel from the APIKey user InBox or Archive.
	- [ParcelDownloadConfirm](https://os.ecgrid.io/v4.1/prod/ECGridOS.asmx?op=ParcelDownloadConfirm) 
		- Confirm Download of Parcel from the APIKey user InBox and remove it.
	- [ParcelDownloadReset](https://os.ecgrid.io/v4.1/prod/ECGridOS.asmx?op=ParcelDownloadReset) 
		- Reset Download of Parcel and restore to the APIKey user InBox.
